#include "SDL.h"
#include <tk.h>

/* This is how far the image moves each time its moved */
#define STEP 2

int MAX_X,MAX_Y; /* These are set to (width of the screen - the size
			of the cursor) once we know how big the screen is */
int MIN_X = 0;
int MIN_Y = 0;
SDL_Surface *screen, *cursor, *buff;
SDL_Rect back, cur;
Tcl_Interp *interp;

/* Our function to exit both programs nicely */
int destroy_SDL() {
   Tcl_Eval(interp, "exit");
   SDL_Quit();
   return 0;
}

/* Our functions for movement called by both tcl/tk and SDL */
int do_up() {
   SDL_Rect old[2];

   old[0] = back;
   SDL_BlitSurface(buff, &cur,screen,&back);
   back.y -= STEP;
   if (back.y < MIN_Y) {
      back.y = MIN_Y;
   }
   SDL_BlitSurface(screen,&back, buff, &cur);
   SDL_BlitSurface(cursor,&cur,screen,&back);
   old[1] = back;
   SDL_UpdateRects(screen,2,old);
   return 0;
}

int do_down() {
   SDL_Rect old[2];

   old[0] = back;
   SDL_BlitSurface(buff, &cur,screen,&back);
   back.y += STEP;
   if (back.y > MAX_Y) {
      back.y = MAX_Y;
   }
   SDL_BlitSurface(screen,&back, buff, &cur);
   SDL_BlitSurface(cursor,&cur,screen,&back);
   old[1] = back;
   SDL_UpdateRects(screen,2,old);
   return 0;
}

int do_left() {
   SDL_Rect old[2];

   old[0] = back;
   SDL_BlitSurface(buff, &cur,screen,&back);
   back.x -= STEP;
   if (back.x < MIN_X) {
      back.x = MIN_X;
   }
   SDL_BlitSurface(screen,&back, buff, &cur);
   SDL_BlitSurface(cursor,&cur,screen,&back);
   old[1] = back;
   SDL_UpdateRects(screen,2,old);
   return 0;
}

int do_right() {
   SDL_Rect old[2];

   old[0] = back;
   SDL_BlitSurface(buff, &cur,screen,&back);
   back.x += STEP;
   if (back.x > MAX_X) {
      back.x = MAX_X;
   }
   SDL_BlitSurface(screen,&back, buff, &cur);
   SDL_BlitSurface(cursor,&cur,screen,&back);
   old[1] = back;
   SDL_UpdateRects(screen,2,old);
   return 0;
}

/* Setup the tcl/tk interface */
int mytk_init(int argc, char *argv[]) {

   interp = Tcl_CreateInterp();
   if (Tcl_Init(interp) == TCL_ERROR) { return TCL_ERROR; }
   if (Tk_Init(interp) == TCL_ERROR) { return TCL_ERROR; }
   Tcl_CreateCommand(interp, "do_up", do_up,
                (ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
   Tcl_CreateCommand(interp, "do_down", do_down,
                (ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
   Tcl_CreateCommand(interp, "do_left", do_left,
                (ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
   Tcl_CreateCommand(interp, "do_right", do_right,
                (ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
   Tcl_CreateCommand(interp, "destroy_SDL", destroy_SDL,
                (ClientData)NULL, (Tcl_CmdDeleteProc *)NULL);
   if (Tcl_EvalFile(interp, "menu.tcl") == TCL_ERROR ) { return TCL_ERROR; }
   return 1;
}

/* Setup the SDL surface and load the cursor */
int mysdl_init() {
   Uint16 width = 640;
   Uint16 height = 480;
   Uint8 bits = 8;

   if ( SDL_Init(SDL_INIT_EVERYTHING) < 0 ) {
      fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
      return 0;
   }
   atexit(destroy_SDL);
   SDL_WM_SetCaption("Demo using tcl/tk", "tcl/tk demo");
   screen = SDL_SetVideoMode(width, height, bits, SDL_SWSURFACE|SDL_ANYFORMAT);
   if ( screen == NULL ) {
      fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
      return 0;
   }
   myclear_screen(1,1,1);   

   /*setup the cursor */
   cursor = SDL_LoadBMP("cursor.bmp");
   buff = SDL_CreateRGBSurface(SDL_SWSURFACE,cursor->w,cursor->h,8,0,0,0,0);
   if (cursor == NULL) {
      fprintf(stderr, "Couldn't initialize SDL: %s\n",SDL_GetError());
      return 0;
   }

   /* inialize our palette */
   if ( cursor->format->palette ) {
      SDL_SetColors(screen, cursor->format->palette->colors, 0,
         cursor->format->palette->ncolors);
   }

   /* setup our buffers so that we can blit nicely, the gist of this is
      copy the background to buff so we can copy it back when we move
      the cursor.  Then copy the cursor to the background */
   MAX_X = screen->w - cursor->w;
   MAX_Y = screen->h - cursor->h;
   MIN_X = 0;
   MIN_Y = 0;
   back.h = cursor->h;
   back.w = cursor->w;
   cur.h = back.h;
   cur.w = back.w;

   back.x = screen->h/2;
   back.y = screen->w/2;

   cur.x = 0;
   cur.y = 0;

   /* Do our initall backup and copy stuff */
   SDL_BlitSurface(screen, &back, buff, &cur);
   SDL_BlitSurface(cursor, &cur, screen, &back);
   SDL_Flip(screen);
   return 1;
}

int myclear_screen(int r, int g, int b) {
   Uint32 mypixel;

   mypixel = SDL_MapRGB(screen->format, r, g, b);
   SDL_FillRect(screen,NULL,mypixel);
   SDL_Flip(screen);
   return 1;
}

/* Event loop which if idle parsed tcl/tk events */
int mySDLmain_loop() {
   int done = 0;
   Uint8 *keys;
   SDL_Event event;

   while(1) {
      if (SDL_PollEvent(&event) == 0) {
         Tk_DoOneEvent(TK_ALL_EVENTS|TK_DONT_WAIT);
      } else {
         if (event.type == SDL_KEYDOWN) {
            keys = SDL_GetKeyState(NULL);
            if (keys[SDLK_ESCAPE] == SDL_PRESSED) {
               return 1;
            }
            if (keys[SDLK_UP] == SDL_PRESSED) {
               do_up();
            }
            if (keys[SDLK_DOWN] == SDL_PRESSED) {
               do_down();
            }
            if (keys[SDLK_LEFT] == SDL_PRESSED) {
               do_left();
            }
            if (keys[SDLK_RIGHT] == SDL_PRESSED) {
              do_right();
            }
         } else if (event.type == SDL_QUIT) {
            return 1;
         }
      }
   }
   return 0;
}

int main(int argc, char *argv[]) {
   if (!mytk_init(argc, argv)) {
      return 0;
   }
   if (!mysdl_init()) {
      return 0;
   }
   return mySDLmain_loop(); 		/* Enter MainLoop */
}
