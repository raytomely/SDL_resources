/*
    SDL_cbs:  A GLUT-style loop/callback system for SDL
    Copyright (C) 2001  Oliver Gantert

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Oliver Gantert
    lucyg@gmx.net
	http://www.geocities.com/killingdying
	http://drake.here.de
*/
#ifndef SDL_cbs_h
#define SDL_cbs_h

/* Init/quit callback system, return 0 on error */
int SDLCbs_Init(void);
int SDLCbs_Quit(void);

/*** Note: all callbacks may be set (and default) to NULL ***/

/* Display is a special callback, as it's only called
   once for every SDLCbs_PostRedisplay() */
void SDLCbs_DisplayFunc(void (*func)(void));
/* The idle func is called in every loop iteration */
void SDLCbs_IdleFunc(void (*func)(void));

/* Assign a callback function for every SDL event */
void SDLCbs_ActiveFunc(void (*func)(SDL_ActiveEvent *aev));
void SDLCbs_KeyboardFunc(void (*func)(SDL_KeyboardEvent *kev));
void SDLCbs_MouseMotionFunc(void (*func)(SDL_MouseMotionEvent *mmev));
void SDLCbs_MouseButtonFunc(void (*func)(SDL_MouseButtonEvent *mbev));
void SDLCbs_JoyAxisFunc(void (*func)(SDL_JoyAxisEvent *jaev));
void SDLCbs_JoyBallFunc(void (*func)(SDL_JoyBallEvent *jbev));
void SDLCbs_JoyHatFunc(void (*func)(SDL_JoyHatEvent *jhev));
void SDLCbs_JoyButtonFunc(void (*func)(SDL_JoyButtonEvent *jbev));
void SDLCbs_ResizeFunc(void (*func)(SDL_ResizeEvent *rev));
void SDLCbs_QuitFunc(void (*func)(SDL_QuitEvent *qev));
void SDLCbs_UserFunc(void (*func)(SDL_UserEvent *uev));
void SDLCbs_SysWMFunc(void (*func)(SDL_SysWMEvent *sev));

/* Enter main loop: handle events, process callbacks */
void SDLCbs_MainLoop(void);
/* Exit main loop. You can re-enter with SDLCbs_MainLoop(). */
void SDLCbs_ExitLoop(void);

/* Post redisplay. This tells the main loop to call the
   display function. */
void SDLCbs_PostRedisplay(void);

#endif /* SDL_cbs_h */
