/*
    SDL_cbs:  A GLUT-style loop/callback system for SDL
    Copyright (C) 2001  Oliver Gantert

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Oliver Gantert
    lucyg@gmx.net
	http://www.geocities.com/killingdying
	http://drake.here.de
*/
#include <stdlib.h>
#include <string.h>
#include <SDL.h>
#include "SDL_cbs.h"

typedef struct
{
	void	(*_display)(void);
	void	(*_idle)(void);
	void	(*_active)(SDL_ActiveEvent *aev);
	void	(*_key)(SDL_KeyboardEvent *kev);
	void	(*_motion)(SDL_MouseMotionEvent *mev);
	void	(*_button)(SDL_MouseButtonEvent *bev);
	void	(*_jaxis)(SDL_JoyAxisEvent *jaev);
	void	(*_jball)(SDL_JoyBallEvent *jbev);
	void	(*_jhat)(SDL_JoyHatEvent *jhev);
	void	(*_jbutton)(SDL_JoyButtonEvent *jbev);
	void	(*_resize)(SDL_ResizeEvent *rev);
	void	(*_quit)(SDL_QuitEvent *qev);
	void	(*_user)(SDL_UserEvent *uev);
	void	(*_syswm)(SDL_SysWMEvent *sev);
	char	loop_terminated;
	char	posted_redisplay;
} sdlcbs_s;

static sdlcbs_s *sdlcbs = NULL;

int SDLCbs_Init(void)
{
	if (sdlcbs)
	{
		return(-1);
	}
	if (sdlcbs = (sdlcbs_s *)malloc(sizeof(sdlcbs_s)))
	{
		memset(sdlcbs, 0, sizeof(sdlcbs_s));
		sdlcbs->loop_terminated = -1;
		return(-1);
	}
	return(0);
}

int SDLCbs_Quit(void)
{
	if (sdlcbs)
	{
		if (sdlcbs->loop_terminated)
		{
			free(sdlcbs);
			sdlcbs = NULL;
			return(-1);
		}
	}
	return(0);
}

void SDLCbs_DisplayFunc(void (*func)(void))
{
	if (sdlcbs)
	{
		sdlcbs->_display = func;
	}
}

void SDLCbs_IdleFunc(void (*func)(void))
{
	if (sdlcbs)
	{
		sdlcbs->_idle = func;
	}
}

void SDLCbs_ActiveFunc(void (*func)(SDL_ActiveEvent *aev))
{
	if (sdlcbs)
	{
		sdlcbs->_key = func;
	}
}

void SDLCbs_KeyboardFunc(void (*func)(SDL_KeyboardEvent *kev))
{
	if (sdlcbs)
	{
		sdlcbs->_key = func;
	}
}

void SDLCbs_MouseMotionFunc(void (*func)(SDL_MouseMotionEvent *mmev))
{
	if (sdlcbs)
	{
		sdlcbs->_motion = func;
	}
}

void SDLCbs_MouseButtonFunc(void (*func)(SDL_MouseButtonEvent *mbev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_JoyAxisFunc(void (*func)(SDL_JoyAxisEvent *jaev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_JoyBallFunc(void (*func)(SDL_JoyBallEvent *jbev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_JoyHatFunc(void (*func)(SDL_JoyHatEvent *jhev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_JoyButtonFunc(void (*func)(SDL_JoyButtonEvent *jbev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_ResizeFunc(void (*func)(SDL_ResizeEvent *rev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_QuitFunc(void (*func)(SDL_QuitEvent *qev))
{
	if (sdlcbs)
	{
		sdlcbs->_quit = func;
	}
}

void SDLCbs_UserFunc(void (*func)(SDL_UserEvent *uev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_SysWMFunc(void (*func)(SDL_SysWMEvent *sev))
{
	if (sdlcbs)
	{
		sdlcbs->_button = func;
	}
}

void SDLCbs_MainLoop(void)
{
	SDL_Event event;

	if (sdlcbs)
	{
		sdlcbs->loop_terminated = 0;
		while (!sdlcbs->loop_terminated)
		{
			while (SDL_PollEvent(&event))
			{
				switch (event.type)
				{
					case SDL_ACTIVEEVENT:
						if (sdlcbs->_active)
						{
							sdlcbs->_active(&event.active);
						}
					break;
					case SDL_KEYDOWN:
					case SDL_KEYUP:
						if (sdlcbs->_key)
						{
							sdlcbs->_key(&event.key);
						}
					break;
					case SDL_MOUSEMOTION:
						if (sdlcbs->_motion)
						{
							sdlcbs->_motion(&event.motion);
						}
					break;
					case SDL_MOUSEBUTTONDOWN:
					case SDL_MOUSEBUTTONUP:
						if (sdlcbs->_button)
						{
							sdlcbs->_button(&event.button);
						}
					break;
					case SDL_JOYAXISMOTION:
						if (sdlcbs->_jaxis)
						{
							sdlcbs->_jaxis(&event.jaxis);
						}
					break;
					case SDL_JOYBALLMOTION:
						if (sdlcbs->_jball)
						{
							sdlcbs->_jball(&event.jball);
						}
					break;
					case SDL_JOYHATMOTION:
						if (sdlcbs->_jhat)
						{
							sdlcbs->_jhat(&event.jhat);
						}
					break;
					case SDL_JOYBUTTONDOWN:
					case SDL_JOYBUTTONUP:
						if (sdlcbs->_jbutton)
						{
							sdlcbs->_jbutton(&event.jbutton);
						}
					break;
					case SDL_QUIT:
						if (sdlcbs->_quit)
						{
							sdlcbs->_quit();
						}
					break;
					case SDL_SYSWMEVENT:
						if (sdlcbs->_syswm)
						{
							sdlcbs->_syswm(&event.syswm);
						}
					break;
					case SDL_VIDEORESIZE:
						if (sdlcbs->_resize)
						{
							sdlcbs->_resize(&event.resize);
						}
					break;
					case SDL_USEREVENT:
						if (sdlcbs->_user)
						{
							sdlcbs->_user(&event.user);
						}
					break;
				}
			}
			if (sdlcbs->_idle)
			{
				sdlcbs->_idle();
			}
			if ((sdlcbs->posted_redisplay) && (sdlcbs->_display))
			{
				sdlcbs->posted_redisplay = 0;
				sdlcbs->_display();
			}
		}
	}
}

void SDLCbs_ExitLoop(void)
{
	if (sdlcbs)
	{
		sdlcbs->loop_terminated = -1;
	}
}

void SDLCbs_PostRedisplay(void)
{
	if (sdlcbs)
	{
		sdlcbs->posted_redisplay = -1;
	}
}
